// api-integration.js
// Add this script BEFORE your existing JavaScript in your HTML file
// This will handle all API communication without changing your existing code structure

(function() {
    'use strict';

    // API Configuration
    const API_BASE_URL = 'http://localhost:5000/api';
    let authToken = localStorage.getItem('authToken');

    // API Helper Functions
    const API = {
        // Set auth token
        setToken(token) {
            authToken = token;
            localStorage.setItem('authToken', token);
        },

        // Clear auth token
        clearToken() {
            authToken = null;
            localStorage.removeItem('authToken');
        },

        // Get headers
        getHeaders(includeAuth = false) {
            const headers = {
                'Content-Type': 'application/json'
            };
            if (includeAuth && authToken) {
                headers['Authorization'] = `Bearer ${authToken}`;
            }
            return headers;
        },

        // Make API request
        async request(endpoint, options = {}) {
            try {
                const response = await fetch(`${API_BASE_URL}${endpoint}`, {
                    ...options,
                    headers: this.getHeaders(options.auth)
                });

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.error || 'API request failed');
                }

                return data;
            } catch (error) {
                console.error('API Error:', error);
                throw error;
            }
        },

        // Register user
        async register(userData) {
            return await this.request('/register', {
                method: 'POST',
                body: JSON.stringify(userData)
            });
        },

        // Login user
        async login(credentials) {
            const data = await this.request('/login', {
                method: 'POST',
                body: JSON.stringify(credentials)
            });
            
            if (data.token) {
                this.setToken(data.token);
            }
            
            return data;
        },

        // Get user profile
        async getProfile() {
            return await this.request('/profile', {
                auth: true
            });
        },

        // Update game state
        async updateGameState(gameState) {
            return await this.request('/gamestate', {
                method: 'PUT',
                auth: true,
                body: JSON.stringify({ gameState })
            });
        },

        // Get leaderboard
        async getLeaderboard(filter = 'global', classLevel = null) {
            const params = new URLSearchParams();
            if (filter) params.append('filter', filter);
            if (classLevel) params.append('classLevel', classLevel);
            
            return await this.request(`/leaderboard?${params.toString()}`);
        },

        // Get user stats
        async getStats() {
            return await this.request('/stats', {
                auth: true
            });
        },

        // Delete account
        async deleteAccount(password) {
            return await this.request('/account', {
                method: 'DELETE',
                auth: true,
                body: JSON.stringify({ password })
            });
        }
    };

    // Override the existing handleRegister function
    window.originalHandleRegister = window.handleRegister;
    window.handleRegister = async function(event) {
        event.preventDefault();
        
        const name = document.getElementById('registerName').value.trim();
        const username = document.getElementById('registerUsername').value.trim();
        const email = document.getElementById('registerEmail').value.trim();
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('registerConfirmPassword').value;
        
        // Client-side validation
        if (username.length < 3) {
            alert('❌ Username must be at least 3 characters long!');
            return;
        }
        
        if (password.length < 6) {
            alert('❌ Password must be at least 6 characters long!');
            return;
        }
        
        if (password !== confirmPassword) {
            alert('❌ Passwords do not match!');
            return;
        }

        try {
            const result = await API.register({
                name,
                username,
                email,
                password
            });

            alert('✅ Account created successfully! Please login.');
            showLogin();
            document.getElementById('loginUsername').value = username;
        } catch (error) {
            alert(`❌ ${error.message}`);
        }
    };

    // Override the existing handleLogin function
    window.originalHandleLogin = window.handleLogin;
    window.handleLogin = async function(event) {
        event.preventDefault();
        
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value;

        try {
            const result = await API.login({ username, password });

            // Store user data
            currentUser = result.user.username;
            localStorage.setItem('currentUser', currentUser);

            // Load game state from database
            if (result.user.gameState) {
                gameState = { ...gameState, ...result.user.gameState };
            }

            // Store user data in the users object for compatibility
            users[currentUser] = {
                name: result.user.name,
                username: result.user.username,
                email: result.user.email,
                joinDate: result.user.joinDate,
                gameState: result.user.gameState
            };

            document.getElementById('authScreen').classList.add('hidden');
            document.getElementById('mainApp').classList.remove('hidden');
            
            loadUserData();
            init();

            // Fetch and update leaderboard
            updateLeaderboardFromAPI();

        } catch (error) {
            alert(`❌ ${error.message}`);
        }
    };

    // Override the existing saveUserData function
    window.originalSaveUserData = window.saveUserData;
    window.saveUserData = async function() {
        if (!currentUser || !authToken) return;

        try {
            // Call original function for local storage backup
            if (window.originalSaveUserData) {
                window.originalSaveUserData();
            }

            // Save to database
            await API.updateGameState({
                selectedClass: gameState.selectedClass,
                level: gameState.level,
                currentXP: gameState.currentXP,
                maxXP: gameState.maxXP,
                totalXP: gameState.totalXP,
                streak: gameState.streak,
                notes: gameState.notes,
                todos: gameState.todos,
                notifications: gameState.notifications,
                earnedBadges: gameState.earnedBadges,
                quizzesCompleted: gameState.quizzesCompleted,
                theme: gameState.theme,
                soundEnabled: gameState.soundEnabled,
                notificationsEnabled: gameState.notificationsEnabled,
                autoSave: gameState.autoSave,
                language: gameState.language,
                difficulty: gameState.difficulty,
                reminder: gameState.reminder,
                fontSize: gameState.fontSize
            });

            console.log('✅ Game state saved to database');
        } catch (error) {
            console.error('Failed to save to database:', error);
            // Still have local storage as backup
        }
    };

    // Override handleLogout
    window.originalHandleLogout = window.handleLogout;
    window.handleLogout = async function() {
        if (confirm('Are you sure you want to logout?')) {
            await saveUserData();
            
            API.clearToken();
            localStorage.removeItem('currentUser');
            currentUser = null;
            
            document.getElementById('authScreen').classList.remove('hidden');
            document.getElementById('mainApp').classList.add('hidden');
            showLogin();
            
            document.getElementById('loginUsername').value = '';
            document.getElementById('loginPassword').value = '';
        }
    };

    // Function to update leaderboard from API
    window.updateLeaderboardFromAPI = async function(filter = 'global') {
        try {
            const result = await API.getLeaderboard(filter, gameState.selectedClass);
            
            if (result.success && result.leaderboard) {
                // Update leaderboard data
                leaderboardData[filter] = result.leaderboard.map(user => ({
                    name: user.name,
                    avatar: user.username.substring(0, 2).toUpperCase(),
                    level: user.level,
                    totalXP: user.totalXP,
                    class: user.class,
                    isCurrentUser: user.username === currentUser
                }));

                // Re-render leaderboard
                renderLeaderboard();
            }
        } catch (error) {
            console.error('Failed to fetch leaderboard:', error);
        }
    };

    // Function to fetch user stats
    window.fetchUserStats = async function() {
        try {
            const result = await API.getStats();
            
            if (result.success) {
                document.getElementById('yourRank').textContent = `#${result.stats.rank}`;
                document.getElementById('yourTotalXP').textContent = result.stats.totalXP;
                document.getElementById('quizzesCompleted').textContent = result.stats.quizzesCompleted;
            }
        } catch (error) {
            console.error('Failed to fetch stats:', error);
        }
    };

    // Check if user is logged in on page load
    window.addEventListener('DOMContentLoaded', function() {
        if (authToken && currentUser) {
            // Try to restore session
            API.getProfile().then(result => {
                if (result.success) {
                    console.log('✅ Session restored');
                    // Update game state from server
                    if (result.user.gameState) {
                        gameState = { ...gameState, ...result.user.gameState };
                    }
                }
            }).catch(error => {
                console.error('Session restoration failed:', error);
                API.clearToken();
            });
        }
    });

    // Auto-save every 30 seconds
    setInterval(() => {
        if (currentUser && authToken) {
            saveUserData();
        }
    }, 30000);

    // Expose API object globally for debugging
    window.API = API;

    console.log('✅ API Integration loaded successfully');
})();
