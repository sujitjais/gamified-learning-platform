// server.js - Main Backend Server
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public')); // Serve your HTML file from 'public' folder

// MongoDB Connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/rural-learning-quest';
mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('✅ Connected to MongoDB'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// User Schema
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    username: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    password: {
        type: String,
        required: true
    },
    joinDate: {
        type: Date,
        default: Date.now
    },
    gameState: {
        selectedClass: { type: String, default: '1-2' },
        level: { type: Number, default: 1 },
        currentXP: { type: Number, default: 0 },
        maxXP: { type: Number, default: 100 },
        totalXP: { type: Number, default: 0 },
        streak: { type: Number, default: 0 },
        notes: { type: Array, default: [] },
        todos: { type: Array, default: [] },
        notifications: { type: Array, default: [] },
        earnedBadges: { type: Array, default: [] },
        quizzesCompleted: { type: Number, default: 0 },
        theme: { type: String, default: 'light' },
        soundEnabled: { type: Boolean, default: true },
        notificationsEnabled: { type: Boolean, default: true },
        autoSave: { type: Boolean, default: true },
        language: { type: String, default: 'en' },
        difficulty: { type: String, default: 'medium' },
        reminder: { type: String, default: 'evening' },
        fontSize: { type: String, default: 'medium' }
    },
    lastLogin: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

// Method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

const User = mongoose.model('User', userSchema);

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production';

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token' });
        }
        req.user = user;
        next();
    });
};

// ==================== ROUTES ====================

// 1. REGISTER
app.post('/api/register', async (req, res) => {
    try {
        const { name, username, email, password } = req.body;

        // Validation
        if (!name || !username || !email || !password) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        if (username.length < 3) {
            return res.status(400).json({ error: 'Username must be at least 3 characters long' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters long' });
        }

        // Check if user already exists
        const existingUser = await User.findOne({
            $or: [{ username: username.toLowerCase() }, { email: email.toLowerCase() }]
        });

        if (existingUser) {
            if (existingUser.username === username.toLowerCase()) {
                return res.status(400).json({ error: 'Username already exists' });
            }
            if (existingUser.email === email.toLowerCase()) {
                return res.status(400).json({ error: 'Email already registered' });
            }
        }

        // Create new user
        const user = new User({
            name,
            username: username.toLowerCase(),
            email: email.toLowerCase(),
            password
        });

        await user.save();

        res.status(201).json({
            success: true,
            message: 'Account created successfully',
            username: user.username
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Server error during registration' });
    }
});

// 2. LOGIN
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Validation
        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password are required' });
        }

        // Find user by username or email
        const user = await User.findOne({
            $or: [
                { username: username.toLowerCase() },
                { email: username.toLowerCase() }
            ]
        });

        if (!user) {
            return res.status(401).json({ error: 'User not found' });
        }

        // Check password
        const isPasswordValid = await user.comparePassword(password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Incorrect password' });
        }

        // Update last login
        user.lastLogin = Date.now();
        await user.save();

        // Generate JWT token
        const token = jwt.sign(
            { 
                userId: user._id, 
                username: user.username 
            },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            token,
            user: {
                name: user.name,
                username: user.username,
                email: user.email,
                joinDate: user.joinDate,
                gameState: user.gameState
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Server error during login' });
    }
});

// 3. GET USER PROFILE
app.get('/api/profile', authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.userId).select('-password');
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({
            success: true,
            user: {
                name: user.name,
                username: user.username,
                email: user.email,
                joinDate: user.joinDate,
                gameState: user.gameState,
                lastLogin: user.lastLogin
            }
        });

    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({ error: 'Server error fetching profile' });
    }
});

// 4. UPDATE GAME STATE
app.put('/api/gamestate', authenticateToken, async (req, res) => {
    try {
        const { gameState } = req.body;

        if (!gameState) {
            return res.status(400).json({ error: 'Game state data required' });
        }

        const user = await User.findById(req.user.userId);
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Update game state
        user.gameState = { ...user.gameState, ...gameState };
        await user.save();

        res.json({
            success: true,
            message: 'Game state updated successfully',
            gameState: user.gameState
        });

    } catch (error) {
        console.error('Game state update error:', error);
        res.status(500).json({ error: 'Server error updating game state' });
    }
});

// 5. GET LEADERBOARD
app.get('/api/leaderboard', async (req, res) => {
    try {
        const { filter = 'global', classLevel } = req.query;

        let query = {};
        let sortBy = { 'gameState.totalXP': -1 };
        let limit = 50;

        // Filter by class if specified
        if (classLevel) {
            query['gameState.selectedClass'] = classLevel;
        }

        // Get top users
        const users = await User.find(query)
            .select('name username gameState.level gameState.totalXP gameState.selectedClass')
            .sort(sortBy)
            .limit(limit);

        const leaderboard = users.map((user, index) => ({
            rank: index + 1,
            name: user.name,
            username: user.username,
            level: user.gameState.level,
            totalXP: user.gameState.totalXP,
            class: user.gameState.selectedClass
        }));

        res.json({
            success: true,
            leaderboard
        });

    } catch (error) {
        console.error('Leaderboard fetch error:', error);
        res.status(500).json({ error: 'Server error fetching leaderboard' });
    }
});

// 6. GET USER STATS
app.get('/api/stats', authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.userId);
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Calculate rank
        const higherRankedUsers = await User.countDocuments({
            'gameState.totalXP': { $gt: user.gameState.totalXP }
        });
        const rank = higherRankedUsers + 1;

        // Get total users
        const totalUsers = await User.countDocuments();

        res.json({
            success: true,
            stats: {
                rank,
                totalUsers,
                level: user.gameState.level,
                totalXP: user.gameState.totalXP,
                quizzesCompleted: user.gameState.quizzesCompleted,
                streak: user.gameState.streak,
                earnedBadges: user.gameState.earnedBadges.length
            }
        });

    } catch (error) {
        console.error('Stats fetch error:', error);
        res.status(500).json({ error: 'Server error fetching stats' });
    }
});

// 7. DELETE ACCOUNT
app.delete('/api/account', authenticateToken, async (req, res) => {
    try {
        const { password } = req.body;

        if (!password) {
            return res.status(400).json({ error: 'Password required to delete account' });
        }

        const user = await User.findById(req.user.userId);
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Verify password
        const isPasswordValid = await user.comparePassword(password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Incorrect password' });
        }

        await User.findByIdAndDelete(req.user.userId);

        res.json({
            success: true,
            message: 'Account deleted successfully'
        });

    } catch (error) {
        console.error('Account deletion error:', error);
        res.status(500).json({ error: 'Server error deleting account' });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        message: 'Rural Learning Quest API is running',
        timestamp: new Date().toISOString()
    });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📚 Rural Learning Quest Backend Ready!`);
});
