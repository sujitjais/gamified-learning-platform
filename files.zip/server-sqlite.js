// server-sqlite.js - Simplified Backend with SQLite (No MongoDB needed!)
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// SQLite Database Setup
const db = new sqlite3.Database('./rural-learning-quest.db', (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('✅ Connected to SQLite database');
        initializeDatabase();
    }
});

// Initialize Database Tables
function initializeDatabase() {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME DEFAULT CURRENT_TIMESTAMP,
            game_state TEXT DEFAULT '{}',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) {
            console.error('Error creating users table:', err);
        } else {
            console.log('✅ Database tables initialized');
        }
    });
}

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production';

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token' });
        }
        req.user = user;
        next();
    });
};

// Helper function to get user by username or email
function findUserByCredentials(username, callback) {
    db.get(
        'SELECT * FROM users WHERE username = ? OR email = ?',
        [username.toLowerCase(), username.toLowerCase()],
        callback
    );
}

// ==================== ROUTES ====================

// 1. REGISTER
app.post('/api/register', async (req, res) => {
    try {
        const { name, username, email, password } = req.body;

        // Validation
        if (!name || !username || !email || !password) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        if (username.length < 3) {
            return res.status(400).json({ error: 'Username must be at least 3 characters long' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters long' });
        }

        // Check if user exists
        findUserByCredentials(username, async (err, existingUser) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            if (existingUser) {
                if (existingUser.username === username.toLowerCase()) {
                    return res.status(400).json({ error: 'Username already exists' });
                }
                if (existingUser.email === email.toLowerCase()) {
                    return res.status(400).json({ error: 'Email already registered' });
                }
            }

            // Hash password
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);

            // Insert new user
            db.run(
                `INSERT INTO users (name, username, email, password, game_state) VALUES (?, ?, ?, ?, ?)`,
                [name, username.toLowerCase(), email.toLowerCase(), hashedPassword, '{}'],
                function(err) {
                    if (err) {
                        return res.status(500).json({ error: 'Error creating user' });
                    }

                    res.status(201).json({
                        success: true,
                        message: 'Account created successfully',
                        username: username.toLowerCase()
                    });
                }
            );
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Server error during registration' });
    }
});

// 2. LOGIN
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password are required' });
        }

        findUserByCredentials(username, async (err, user) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            if (!user) {
                return res.status(401).json({ error: 'User not found' });
            }

            // Check password
            const isPasswordValid = await bcrypt.compare(password, user.password);
            if (!isPasswordValid) {
                return res.status(401).json({ error: 'Incorrect password' });
            }

            // Update last login
            db.run('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);

            // Generate JWT token
            const token = jwt.sign(
                { userId: user.id, username: user.username },
                JWT_SECRET,
                { expiresIn: '7d' }
            );

            // Parse game state
            let gameState = {};
            try {
                gameState = JSON.parse(user.game_state || '{}');
            } catch (e) {
                gameState = {};
            }

            res.json({
                success: true,
                token,
                user: {
                    name: user.name,
                    username: user.username,
                    email: user.email,
                    joinDate: user.join_date,
                    gameState: gameState
                }
            });
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Server error during login' });
    }
});

// 3. GET USER PROFILE
app.get('/api/profile', authenticateToken, (req, res) => {
    db.get('SELECT * FROM users WHERE id = ?', [req.user.userId], (err, user) => {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        let gameState = {};
        try {
            gameState = JSON.parse(user.game_state || '{}');
        } catch (e) {
            gameState = {};
        }

        res.json({
            success: true,
            user: {
                name: user.name,
                username: user.username,
                email: user.email,
                joinDate: user.join_date,
                gameState: gameState,
                lastLogin: user.last_login
            }
        });
    });
});

// 4. UPDATE GAME STATE
app.put('/api/gamestate', authenticateToken, (req, res) => {
    const { gameState } = req.body;

    if (!gameState) {
        return res.status(400).json({ error: 'Game state data required' });
    }

    const gameStateJson = JSON.stringify(gameState);

    db.run(
        'UPDATE users SET game_state = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [gameStateJson, req.user.userId],
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Error updating game state' });
            }

            res.json({
                success: true,
                message: 'Game state updated successfully',
                gameState: gameState
            });
        }
    );
});

// 5. GET LEADERBOARD
app.get('/api/leaderboard', (req, res) => {
    const { classLevel } = req.query;

    let query = 'SELECT name, username, game_state FROM users ORDER BY json_extract(game_state, "$.totalXP") DESC LIMIT 50';

    db.all(query, [], (err, users) => {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }

        const leaderboard = users.map((user, index) => {
            let gameState = {};
            try {
                gameState = JSON.parse(user.game_state || '{}');
            } catch (e) {
                gameState = {};
            }

            return {
                rank: index + 1,
                name: user.name,
                username: user.username,
                level: gameState.level || 1,
                totalXP: gameState.totalXP || 0,
                class: gameState.selectedClass || '1-2'
            };
        }).filter(user => {
            if (!classLevel) return true;
            return user.class === classLevel;
        });

        res.json({
            success: true,
            leaderboard
        });
    });
});

// 6. GET USER STATS
app.get('/api/stats', authenticateToken, (req, res) => {
    db.get('SELECT game_state FROM users WHERE id = ?', [req.user.userId], (err, user) => {
        if (err || !user) {
            return res.status(500).json({ error: 'Database error' });
        }

        let gameState = {};
        try {
            gameState = JSON.parse(user.game_state || '{}');
        } catch (e) {
            gameState = {};
        }

        const userXP = gameState.totalXP || 0;

        // Calculate rank
        db.get(
            'SELECT COUNT(*) as count FROM users WHERE json_extract(game_state, "$.totalXP") > ?',
            [userXP],
            (err, result) => {
                if (err) {
                    return res.status(500).json({ error: 'Database error' });
                }

                const rank = (result.count || 0) + 1;

                db.get('SELECT COUNT(*) as total FROM users', [], (err, totalResult) => {
                    res.json({
                        success: true,
                        stats: {
                            rank,
                            totalUsers: totalResult.total || 0,
                            level: gameState.level || 1,
                            totalXP: gameState.totalXP || 0,
                            quizzesCompleted: gameState.quizzesCompleted || 0,
                            streak: gameState.streak || 0,
                            earnedBadges: (gameState.earnedBadges || []).length
                        }
                    });
                });
            }
        );
    });
});

// 7. DELETE ACCOUNT
app.delete('/api/account', authenticateToken, async (req, res) => {
    const { password } = req.body;

    if (!password) {
        return res.status(400).json({ error: 'Password required to delete account' });
    }

    db.get('SELECT * FROM users WHERE id = ?', [req.user.userId], async (err, user) => {
        if (err || !user) {
            return res.status(404).json({ error: 'User not found' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Incorrect password' });
        }

        db.run('DELETE FROM users WHERE id = ?', [req.user.userId], (err) => {
            if (err) {
                return res.status(500).json({ error: 'Error deleting account' });
            }

            res.json({
                success: true,
                message: 'Account deleted successfully'
            });
        });
    });
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        message: 'Rural Learning Quest API (SQLite) is running',
        timestamp: new Date().toISOString()
    });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📚 Rural Learning Quest Backend (SQLite) Ready!`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('Database connection closed.');
        process.exit(0);
    });
});
